"""
Logging module needs to be imported twice during startup
The first time imports the setup functions
After the setup functions have been called,
the logger can be imported 

All other modules simply need to import the logger

"""
import logging
import sys
import os

global logger, file_path, logfilename

def setup_logfile(path, name, progName="duetPrintGuard"):
	global logger, file_path, logfilename
	file_path = path
	logfilename = name
		
	# Create logger    
	logger = logging.getLogger(__name__)
	logger.propagate = False
	
	# set initial logging level
	logger.setLevel(logging.INFO)

	# Create handler for console output - file output handler is created
	c_handler = logging.StreamHandler(sys.stdout)
	format = f'{progName} "%(asctime)s [%(levelname)s] %(message)s"'
	c_format = logging.Formatter(format)
	c_handler.setFormatter(c_format)
	logger.addHandler(c_handler)
	create_log_file(logger)
	return logger

def create_log_file(console_logger):
	global logger, file_path, logfilename
	
	logfile = os.path.join(file_path, logfilename)
	if os.path.exists(logfile):
		print(f'Removing old logfile {logfile}')
		os.remove(logfile)

	# Create handler for logfile
	f_handler = logging.FileHandler(logfile, mode='w', encoding='utf-8')
	f_format = logging.Formatter("%(asctime)s %(module)s - %(funcName)s:[%(levelname)s] %(message)s","%m-%d %H:%M:%S")
	f_handler.setFormatter(f_format)
	console_logger.addHandler(f_handler)
	logger = console_logger

	logger.info(f'''Logging started at {logfile}''')

	return logger

def set_log_level(log_level,logger):  
	logger.info(f'Log level changed to {log_level}')

	if log_level == 'DEBUG':
		logger.setLevel(logging.DEBUG)
	elif log_level == 'INFO':
		logger.setLevel(logging.INFO)
	else: # warning
		logger.setLevel(logging.WARNING)

	return logger
